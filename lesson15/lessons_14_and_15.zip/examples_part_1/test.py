def show_data_from_test():
    print(__name__)


show_data_from_test()
