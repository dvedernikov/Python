# my_module/messages.py

def welcome_message():
    return "Welcome to the calculation program!"


def farewell_message():
    return "Thank you for using the program. Goodbye!"
