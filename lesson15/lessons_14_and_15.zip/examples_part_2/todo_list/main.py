from controller import Controller


def main():
    controller = Controller()
    controller.menu()


if __name__ == "__main__":
    main()
